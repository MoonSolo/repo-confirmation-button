using System;
using UnityEngine;

namespace ExtractionConfirm
{
    /// <summary>
    /// Drives the confirm button: the shop's purchase stand, cloned out of the extraction point.
    ///
    /// The press is detected here through the game's own grab API instead of a UnityEvent. The
    /// component that normally raises the shop's purchase is driven by the shop's own wiring, which
    /// a cloned, relocated object does not carry, so there is nothing to call. What does carry over
    /// is StaticGrabObject - and PhysGrabber.grabbedStaticGrabObject is exactly what the game
    /// itself checks when a player holds a button, so this reads the same signal the game does.
    ///
    /// The mesh that squashes when pressed is "Shop Button Visual", a child of the stand. The squash
    /// and glow use the extraction point's own animation curve, which is the same one the game plays
    /// on its own buttons.
    /// </summary>
    internal sealed class ConfirmButton : MonoBehaviour
    {
        /// <summary>The squashing mesh inside the shop stand, relative to its root.</summary>
        private const string VisualPath = "Shop Button Visual";

        private static readonly Color LitColor = new Color(1f, 0.5f, 0f);

        private ExtractionPoint _extractionPoint;
        private StaticGrabObject _grabObject;
        private Transform _visual;
        private Vector3 _baseScale;
        private Material _material;
        private Action _onPress;

        private bool _wasGrabbed;
        private float _animEval;
        private bool _animating;

        /// <summary>Binds this button to the extraction point it confirms.</summary>
        public void Setup(ExtractionPoint extractionPoint, StaticGrabObject grabObject, Action onPress)
        {
            _extractionPoint = extractionPoint;
            _onPress = onPress;
            _grabObject = grabObject != null
                ? grabObject
                : GetComponentInChildren<StaticGrabObject>(true);

            // Fall back to the grabbable object so a differently shaped prefab still animates
            // something rather than silently doing nothing on a press.
            _visual = transform.Find(VisualPath);
            if (_visual == null)
                _visual = _grabObject != null ? _grabObject.transform : transform;

            _baseScale = _visual.localScale;

            MeshRenderer renderer = _visual.GetComponent<MeshRenderer>();
            if (renderer != null)
            {
                // .material instantiates a private copy, so the shared shop material is untouched.
                _material = renderer.material;
                if (_material != null && _material.HasProperty("_EmissionColor"))
                    _material.SetColor("_EmissionColor", LitColor);
            }
        }

        public void SetVisible(bool visible)
        {
            if (gameObject.activeSelf != visible)
                gameObject.SetActive(visible);
        }

        private void Update()
        {
            if (_extractionPoint == null || _grabObject == null)
                return;

            bool grabbed = ConfirmGate.IsLocallyGrabbed(_grabObject);
            if (grabbed && !_wasGrabbed)
                Press();

            _wasGrabbed = grabbed;
            Animate();
        }

        private void Press()
        {
            PlayPushVisual();

            if (_onPress != null)
                _onPress();
        }

        /// <summary>Same squash-and-glow the game plays on its own button, using the game's curve.</summary>
        private void PlayPushVisual()
        {
            _animEval = 0f;
            _animating = true;

            // The extraction point already owns a button sound, so the confirm button gets the
            // exact same click without needing an audio asset of our own.
            try
            {
                if (_extractionPoint.soundButton != null)
                    _extractionPoint.soundButton.Play(_visual.position, 1f, 1f, 1f, 1f);
            }
            catch
            {
                // A missing sound must never cost the player the confirmation itself.
            }

            if (_material != null && _material.HasProperty("_EmissionColor"))
                _material.SetColor("_EmissionColor", LitColor);
        }

        private void Animate()
        {
            if (!_animating || _extractionPoint == null)
                return;

            _animEval = Mathf.Clamp01(_animEval + Time.deltaTime * 2f);

            AnimationCurve curve = _extractionPoint.buttonPressAnimationCurve;
            float value = curve != null ? curve.Evaluate(_animEval) : _animEval;
            float squash = Mathf.Lerp(0.1f, value, 0.5f);

            _visual.localScale = new Vector3(_baseScale.x, _baseScale.y * squash, _baseScale.z);

            if (_material != null && _material.HasProperty("_EmissionColor"))
                _material.SetColor("_EmissionColor", Color.Lerp(LitColor, Color.white, value));

            if (_animEval >= 1f)
            {
                _animating = false;
                _visual.localScale = _baseScale;
            }
        }
    }
}