# ExtractionConfirm

A confirmation-button mod for [R.E.P.O.](https://store.steampowered.com/app/2132060/R_E_P_O_/).

When your haul reaches the extraction target, the game normally starts the countdown
immediately. This mod freezes the extraction right before the **3-2-1 countdown** and only
lets it start once a player presses the **physical extraction point button** in the level —
it is not a UI button.

## How the game decides to extract

| State | What happens |
| --- | --- |
| `Idle` | The point waits. Pressing the physical button calls `ExtractionPoint.OnClick()` → `ButtonPress()` → `Active`. |
| `Active` | The extraction area is live; valuables inside count towards `haulGoal`. When `haulGoal` is reached, `HaulChecker()` waits 1.5s and calls `StateSet(Success)`. |
| `Success` | The "!!!!!!!" / check-mark validation, 2 seconds. |
| `Surplus` | Tax-return count-up (only if you went over the goal). |
| `Warning` | **The 3-2-1 countdown with the alarm.** |
| `Extracting` | The tube slams down and the haul is collected. |

The mod blocks exactly one transition — `Success`/`Surplus` → `Warning` — and only while the
player is holding the confirm button.

## What the mod does

Three Harmony patches on `ExtractionPoint`:

| Patch | Role |
| --- | --- |
| `StateSet` (prefix) | Holds the `Warning` transition while unconfirmed, and drives the tube text. |
| `OnClick` (prefix) | A press of the extraction point's own button also confirms. |
| `Start` (prefix) | Clones the shop's purchase stand into a confirm button. Also done on demand when the target is reached, so it does not depend on catching level load. |
| `Update` (postfix) | Shows the confirm button exactly while the point is in use. |

### The confirm button

The button is **the shop's own purchase stand** — the physical thing you press to confirm a
purchase in the shop level. Nothing is shipped: every extraction point prefab already contains it,
at `Shop Station / Shop Button`, and the game only throws it away outside the shop:

```csharp
// ExtractionPoint.Start
if (!isShop)
{
    Object.Destroy(shopStation.gameObject);
    return;
}
```

So the mod's `Start` **prefix** clones that subtree out of the live extraction point before the
destruction happens, and reparents it onto the extraction point with the exact local transform
the game authored (`2.742, 1.173, 1.483` — front-right of the machine, matching the shop on every
level regardless of the machine's rotation).

Consequences worth knowing:

- **No AssetBundle, no extra library, no authoring step.** The button *is* the in-game object, so
  it looks and grabs exactly like the one in the shop.
- **It does not wait for the shop.** Not every extraction point prefab carries a shop station —
  the ones in start rooms and some modules do, others do not. The first stand the mod finds is
  cached as an inactive template, and every extraction point after that is cloned from it, so all
  of them get a button regardless of which level they are in or what order they load.
- **It cannot buy anything.** The clone keeps its grab components but every other behaviour is
  disabled, so the shop's purchase logic never runs on it. Pressing it confirms the extraction.
- **The real shop is untouched.** `SemiFunc.RunIsShop()` levels are skipped entirely, so buying
  still works as normal.
- Each client clones its own copy, because each client has its own copy of the level. The press is
  detected locally through `PhysGrabber.grabbedStaticGrabObject` — exactly what the game checks
  when a player holds a button — and forwarded to the host, which owns the state machine.

### Multiplayer

State changes are host-authoritative in REPO, so:

- The hold is enforced on every client (each runs the same gate), and the countdown is only
  released by the host.
- When a **non-host** player presses the button, the client raises a small Photon event
  (custom event code `177`) carrying the extraction point's `PhotonView` id; the host applies
  the confirmation and the normal `StateSetRPC` starts the countdown for everyone.
- When the **host** presses it, the confirmation applies locally.

Note: the host needs the mod installed for the hold to work at all, and every player who should
be able to press the button needs it installed, because each client clones its own copy.

## Requirements

- R.E.P.O. with [BepInEx 5](https://github.com/BepInEx/BepInEx/releases) (Bleeding Edge package)

No other mods, libraries or asset files are required.

## Install

1. Drop `ExtractionConfirm.dll` into `REPO/BepInEx/plugins/`.
2. Start the game.

Keep exactly **one** copy of the DLL in the whole BepInEx tree: two DLLs with the same plugin GUID
means BepInEx silently skips one of them, and you end up debugging a version you did not mean to run.

A healthy startup looks like this:

```
[Info: BepInEx]      Loading [ExtractionConfirm 1.0.0]
[Info: ExtractionConfirm] ExtractionConfirm 1.0.0 loaded
[Info: ExtractionConfirm] Patched ExtractionPoint.StateSet, ExtractionPoint.OnClick, ExtractionPoint.Start, ExtractionPoint.Update
```

and then, once per extraction point:

```
[Info: ExtractionConfirm] ExtractionPoint.Start reached - preparing the confirm button.
[Info: ExtractionConfirm] Cached the shop stand as the confirm button template.
[Info: ExtractionConfirm] Confirm button created from the shop stand at x, y, z
[Info: ExtractionConfirm] Confirm button shown
```

If `ExtractionPoint.Start reached` is missing, the mod never ran: the level was still loading, or
you quit before it finished. Anything after that line, including `No confirm button: <reason>`,
tells you exactly what the mod decided and why.

If the `created from the shop stand` lines never appear, the level never finished loading its
extraction points — BepInEx only reads the plugins folder when the game process starts, so a
freshly copied DLL has no effect until the game is fully closed and relaunched, and quitting during
the level load gets you nothing.

## Configuration

| Section | Key | Default | Meaning |
| --- | --- | --- | --- |
| General | `Enabled` | `true` | Hold the extraction before the countdown until the physical button is pressed. Set to `false` and restart to disable the mod entirely. |
| Button | `Enabled` | `true` | Show the physical confirm button while the extraction point is in use. |
| Visuals | `HoldText` | `CONFIRM` | Text shown on the extraction tube screen while waiting. |
| Visuals | `ButtonHint` | `Confirm extraction` | Hint shown when looking at the button while waiting. |

The file lives at `BepInEx/config/com.repo.extractionconfirm.cfg`.

## Building

```
build.bat
```

Or directly:

```
dotnet build -c Release
```

Output: `bin\Release\ExtractionConfirm.dll`. Override the game location with
`-p:RepoDir="D:\SteamLibrary\steamapps\common\REPO"`.

## Layout of the code

| File | Role |
| --- | --- |
| [ExtractionConfirmMod.cs](ExtractionConfirmMod.cs) | Plugin entry point, configuration, and the Harmony patch declarations. |
| [ConfirmGate.cs](ConfirmGate.cs) | The hold itself: blocking `StateSet(Warning)`, cloning the shop stand, confirmation handling and the multiplayer Photon event. |
| [ConfirmButton.cs](ConfirmButton.cs) | The physical confirm button: press detection through the game's grab API and the push animation. |

## Status

Built and type-checked against the game's assemblies (`dotnet build -c Release`, 0 warnings).
The state-machine analysis comes from decompiling the shipped `Assembly-CSharp`; an in-game
smoke test (reach a target, confirm, extract — plus one multiplayer run) is still the final word.

Version history:

- `1.0.0` — first release of the rewrite. The confirm button is the **shop's own purchase stand**,
  cloned out of the live extraction point at runtime instead of loaded from an AssetBundle, so the
  mod is a single self-contained DLL with no assets, no companion library and no authoring step.
  The first stand found is cached as a template, so extraction points whose own prefab has no shop
  station still get a button. The button is built both from `ExtractionPoint.Start` and, as a safety
  net, when the extraction reaches its target — so it does not depend on catching level load at the
  right moment.
