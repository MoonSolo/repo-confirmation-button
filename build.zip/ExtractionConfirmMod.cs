using System;
using System.Collections.Generic;
using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using ExitGames.Client.Photon;
using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;

namespace ExtractionConfirm
{
    /// <summary>
    /// Entry point.
    ///
    /// Deliberately minimal: the only things that happen while the game boots are reading the
    /// config and installing two Harmony prefixes on ExtractionPoint. Nothing subscribes to Photon,
    /// nothing runs per frame, and no scene object is created. The multiplayer event hook is
    /// installed lazily, and only once an extraction is actually being held.
    ///
    /// The types are resolved by name at startup so a future game update that renames something
    /// logs an error and leaves the game unpatched instead of failing to load.
    /// </summary>
    [BepInPlugin(PluginGuid, PluginName, PluginVersion)]
    [BepInProcess("REPO.exe")]
    public class ExtractionConfirmPlugin : BaseUnityPlugin, IOnEventCallback
    {
        public const string PluginGuid = "com.repo.extractionconfirm";
        public const string PluginName = "ExtractionConfirm";
        public const string PluginVersion = "1.0.0";

        public static ExtractionConfirmPlugin Instance;
        public static ManualLogSource Log;
        public static ConfirmSettings Settings;

        private Harmony _harmony;

        private void Awake()
        {
            Instance = this;
            Log = Logger;
            Settings = new ConfirmSettings(Config);

            Log.LogInfo($"{PluginName} {PluginVersion} loaded");

            if (!Settings.Enabled.Value)
            {
                Log.LogInfo("Disabled in config - no patches installed");
                return;
            }

            try
            {
                _harmony = new Harmony(PluginGuid);
                ApplyPatches(_harmony);
            }
            catch (Exception ex)
            {
                Log.LogError($"Failed to initialise: {ex}");
            }
        }

        private void OnDestroy()
        {
            if (_harmony != null)
            {
                try { _harmony.UnpatchSelf(); } catch { /* ignore */ }
            }
        }

        /// <summary>
        /// Four patches on ExtractionPoint:
        /// - StateSet: holds the Success/Surplus -> Warning (countdown) transition, and shows or
        ///   hides the confirm button while holding.
        /// - OnClick:  a press of the extraction point's own button acts as a confirmation too.
        /// - Start:    spawns the confirm button next to the extraction point.
        /// - Update:   shows the confirm button exactly while the extraction is held.
        /// </summary>
        private static void ApplyPatches(Harmony harmony)
        {
            Type type = AccessTools.TypeByName("ExtractionPoint");
            if (type == null)
            {
                Log.LogError("ExtractionPoint type not found - ExtractionConfirm is inactive.");
                return;
            }

            if (!ConfirmGate.Resolve(type))
            {
                Log.LogError("ExtractionPoint members missing - ExtractionConfirm is inactive.");
                return;
            }

            MethodInfo stateSet = AccessTools.Method(type, "StateSet");
            if (stateSet == null)
            {
                Log.LogError("ExtractionPoint.StateSet not found - ExtractionConfirm is inactive.");
                return;
            }

            harmony.Patch(stateSet,
                prefix: new HarmonyMethod(typeof(ExtractionPatches), nameof(ExtractionPatches.StateSetPrefix)));

            MethodInfo onClick = AccessTools.Method(type, "OnClick");

            MethodInfo start = AccessTools.Method(type, "Start", Type.EmptyTypes);
            MethodInfo update = AccessTools.Method(type, "Update", Type.EmptyTypes);

            // Report what was actually installed. An unconditional "patched ..." line would claim
            // a hook the mod never got, and that is exactly the kind of thing that sends you
            // looking for the bug in the wrong place when a log stays quiet.
            List<string> patched = new List<string> { "ExtractionPoint.StateSet" };

            if (onClick != null)
            {
                harmony.Patch(onClick,
                    prefix: new HarmonyMethod(typeof(ExtractionPatches), nameof(ExtractionPatches.OnClickPrefix)));
                patched.Add("ExtractionPoint.OnClick");
            }
            else
            {
                Log.LogWarning("ExtractionPoint.OnClick not found - a press of the extraction point's own button may not register.");
            }

            if (start != null)
            {
                // A PREFIX, not a postfix: vanilla Start destroys the whole shopStation hierarchy
                // outside the shop, so the stand has to be cloned before that happens.
                harmony.Patch(start,
                    prefix: new HarmonyMethod(typeof(ExtractionPatches), nameof(ExtractionPatches.StartPrefix)));
                patched.Add("ExtractionPoint.Start");
            }
            else
            {
                Log.LogWarning("ExtractionPoint.Start not found - the confirm button will never spawn.");
            }

            if (update != null)
            {
                harmony.Patch(update,
                    postfix: new HarmonyMethod(typeof(ExtractionPatches), nameof(ExtractionPatches.UpdatePostfix)));
                patched.Add("ExtractionPoint.Update");
            }

            Log.LogInfo("Patched " + string.Join(", ", patched.ToArray()));
        }

        /// <summary>
        /// Installs the Photon event hook on demand. This is called the first time an extraction is
        /// held - never during startup - and is what lets a non-host player's button press reach
        /// the host, which owns the extraction state machine.
        /// </summary>
        internal void EnsureNetworkHook()
        {
            if (_networkHookInstalled)
                return;

            _networkHookInstalled = true;
            PhotonNetwork.AddCallbackTarget(this);
        }

        private bool _networkHookInstalled;

        /// <summary>Receives the multiplayer confirmation event raised by non-host clients.</summary>
        public void OnEvent(EventData eventData)
        {
            try
            {
                ConfirmGate.OnPhotonEvent(eventData);
            }
            catch (Exception ex)
            {
                ConfirmGate.ReportPatchError("OnEvent", ex);
            }
        }
    }

    /// <summary>Live configuration, bound to the BepInEx config file on startup.</summary>
    public class ConfirmSettings
    {
        public readonly ConfigEntry<bool> Enabled;
        public readonly ConfigEntry<bool> SpawnButton;
        public readonly ConfigEntry<string> HoldText;
        public readonly ConfigEntry<string> ButtonHint;

        public ConfirmSettings(ConfigFile config)
        {
            Enabled = config.Bind("General", "Enabled", true,
                "Hold the extraction before the 3-2-1 countdown until the physical extraction point button is pressed. Set to false and restart to disable the mod entirely.");

            SpawnButton = config.Bind("Button", "Enabled", true,
                "Show a physical confirm button next to the extraction point while it is in use. The button is the shop's own purchase stand, cloned at runtime - no extra files needed.");

            HoldText = config.Bind("Visuals", "HoldText", "CONFIRM",
                "Text shown on the extraction tube screen while waiting for the button press.");

            ButtonHint = config.Bind("Visuals", "ButtonHint", "Confirm extraction",
                "Hint shown when looking at the confirm button.");
        }
    }

    /// <summary>
    /// The Harmony patch bodies. Every body fails open: if anything unexpected happens the
    /// vanilla code runs instead, so a bug in the mod can never break the extraction itself.
    /// </summary>
    public static class ExtractionPatches
    {
        /// <summary>
        /// Harmony prefixes return true to RUN the vanilla method and false to skip it, so the
        /// gate's "block it" answer is negated here.
        /// </summary>
        public static bool StateSetPrefix(ExtractionPoint __instance, ExtractionPoint.State newState)
        {
            try
            {
                return !ConfirmGate.ShouldSkipTransition(__instance, newState);
            }
            catch (Exception ex)
            {
                ConfirmGate.ReportPatchError("StateSet", ex);
                return true; // fail open: let the vanilla transition through
            }
        }

        public static bool OnClickPrefix(ExtractionPoint __instance)
        {
            try
            {
                return !ConfirmGate.HandleButtonPress(__instance);
            }
            catch (Exception ex)
            {
                ConfirmGate.ReportPatchError("OnClick", ex);
                return true; // fail open: let the vanilla button logic run
            }
        }

        /// <summary>
        /// Clones the shop's purchase stand out of the extraction point, before vanilla Start
        /// destroys it in a non-shop level.
        /// </summary>
        public static void StartPrefix(ExtractionPoint __instance)
        {
            try
            {
                ConfirmGate.PrepareShopButton(__instance);
            }
            catch (Exception ex)
            {
                ConfirmGate.ReportPatchError("Start", ex);
            }
        }

        /// <summary>Shows the confirm button exactly while the extraction is being held.</summary>
        public static void UpdatePostfix(ExtractionPoint __instance)
        {
            try
            {
                ConfirmGate.Tick(__instance);
            }
            catch (Exception ex)
            {
                ConfirmGate.ReportPatchError("Update", ex);
            }
        }
    }
}
