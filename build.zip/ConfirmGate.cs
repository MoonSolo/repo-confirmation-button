using System;
using System.Collections.Generic;
using System.Reflection;
using BepInEx.Logging;
using ExitGames.Client.Photon;
using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

namespace ExtractionConfirm
{
    /// <summary>
    /// Holds the extraction point in the Success/Surplus state so the automatic transition into
    /// Warning (the 3-2-1 countdown) never happens until the physical button has been pressed.
    ///
    /// Vanilla flow this sits in:
    ///   Idle --physical press--> Active --haulGoal reached--> Success [--Surplus-->] Warning --> Extracting
    ///
    /// THE BUTTON
    /// ----------
    /// The confirm button is the shop's own purchase stand - the physical thing you press to buy an
    /// item. It is not an asset we ship. Every extraction point prefab already contains it, under
    /// "Shop Station / Shop Button"; the game only throws it away in levels that are not shops
    /// (ExtractionPoint.Start calls Object.Destroy on the whole shopStation hierarchy).
    ///
    /// So the mod clones that subtree out of the live extraction point before it is destroyed. That
    /// means: no AssetBundle to ship or load, no Unity authoring step, and the button is the real
    /// in-game object, so it looks and grabs exactly like the one in the shop.
    ///
    /// Each client clones its own copy, because each client has its own copy of the level. The
    /// press is detected locally and forwarded to the host, which owns the state machine - so
    /// there is no networked spawn and nothing to register.
    /// </summary>
    internal static class ConfirmGate
    {
        /// <summary>Custom Photon event code used to forward a non-host button press to the host.</summary>
        public const byte ConfirmEventCode = 177;

        /// <summary>Same orange the game uses for the "READY" tube screen text.</summary>
        private static readonly Color HoldColor = new Color(1f, 0.5f, 0f);

        /// <summary>
        /// Local offset the shop stand sits at inside the extraction point, copied from the shipped
        /// prefab (Shop Station / Shop Button). Used only as a fallback if the hierarchy lookup
        /// fails; normally the clone keeps whatever transform the real object had, which is what
        /// guarantees it lines up with the shop on every level.
        /// </summary>
        private static readonly Vector3 ShopButtonFallbackLocalPosition = new Vector3(2.742f, 1.173f, 1.483f);

        private static readonly HashSet<string> ReportedErrors = new HashSet<string>();

        /// <summary>
        /// A spare, inactive copy of the shop stand, kept so that extraction points whose own
        /// prefab has no shop station still get a confirm button.
        ///
        /// This exists because not every extraction point in the game ships a shop station: the
        /// ones in the start rooms and in some modules have one, others do not. Cloning only from
        /// the current extraction point would therefore work in some levels and silently do
        /// nothing in others. Instead the first stand seen becomes a template and every
        /// extraction point after that is cloned from it, so all of them match.
        /// </summary>
        private static GameObject _standTemplate;

        /// <summary>Reasons we did not build a button, logged once each so a silent no-op is visible.</summary>
        private static readonly HashSet<string> ReportedReasons = new HashSet<string>();

        /// <summary>
        /// Proves the Start prefix actually runs. Without this, a session that quits before the
        /// level finishes loading looks identical to one where the clone silently failed, and there
        /// is no way to tell the two apart from the log.
        /// </summary>
        private static bool _loggedFirstInvocation;

        // Per extraction point state: the spawned confirm button and what it changed on the tube.
        private static readonly Dictionary<ExtractionPoint, HoldState> Holds = new Dictionary<ExtractionPoint, HoldState>();

        private static FieldInfo _currentState;
        private static FieldInfo _isShop;
        private static FieldInfo _shopStation;
        private static FieldInfo _shopButton;
        private static FieldInfo _tubeTextString;
        private static FieldInfo _tubeTextColor;
        private static MethodInfo _tubeScreenTextChange;
        private static FieldInfo _grabbedStaticGrabObject;

        private sealed class HoldState
        {
            public bool Confirmed;
            public bool TextApplied;
            public ConfirmButton Button;
            public string TubeTextOriginal;
            public Color TubeColorOriginal;
        }

        private static ManualLogSource Log => ExtractionConfirmPlugin.Log;
        private static ConfirmSettings Settings => ExtractionConfirmPlugin.Settings;

        /// <summary>Resolves the private game members this mod depends on. False = do not patch.</summary>
        public static bool Resolve(Type extractionPointType)
        {
            try
            {
                _currentState = AccessTools.Field(extractionPointType, "currentState");
                _isShop = AccessTools.Field(extractionPointType, "isShop");
                _shopStation = AccessTools.Field(extractionPointType, "shopStation");
                _shopButton = AccessTools.Field(extractionPointType, "shopButton");
                _tubeTextString = AccessTools.Field(extractionPointType, "tubeScreenTextString");
                _tubeTextColor = AccessTools.Field(extractionPointType, "tubeScreenTextColor");
                _tubeScreenTextChange = AccessTools.Method(extractionPointType, "TubeScreenTextChange");

                Type grabberType = AccessTools.TypeByName("PhysGrabber");
                _grabbedStaticGrabObject = grabberType != null
                    ? AccessTools.Field(grabberType, "grabbedStaticGrabObject")
                    : null;

                bool ok = _currentState != null && _isShop != null
                          && _shopStation != null && _shopButton != null
                          && _tubeTextString != null && _tubeTextColor != null
                          && _tubeScreenTextChange != null && _grabbedStaticGrabObject != null;

                if (!ok)
                {
                    Log?.LogError(
                        "Missing members: "
                        + $"currentState={_currentState != null}, isShop={_isShop != null}, "
                        + $"shopStation={_shopStation != null}, shopButton={_shopButton != null}, "
                        + $"tubeScreenTextString={_tubeTextString != null}, "
                        + $"tubeScreenTextColor={_tubeTextColor != null}, "
                        + $"TubeScreenTextChange={_tubeScreenTextChange != null}, "
                        + $"PhysGrabber.grabbedStaticGrabObject={_grabbedStaticGrabObject != null}");
                }

                return ok;
            }
            catch (Exception ex)
            {
                Log?.LogError($"Failed to resolve game members: {ex}");
                return false;
            }
        }

        // ------------------------------------------------------------------ gate

        /// <summary>
        /// Prefix helper for ExtractionPoint.StateSet: returns true when the vanilla transition
        /// must be skipped, i.e. while the countdown is being held.
        /// </summary>
        public static bool ShouldSkipTransition(ExtractionPoint ep, ExtractionPoint.State newState)
        {
            if (ep == null || _currentState == null || Settings == null || !Settings.Enabled.Value)
                return false;

            HoldState hold = Get(ep);

            if (newState == ExtractionPoint.State.Warning && IsHolding(ep))
            {
                if (hold.Confirmed)
                {
                    hold.Confirmed = false;
                    RestoreTubeText(ep, hold);
                    return false; // confirmed: let the 3-2-1 countdown start
                }

                ApplyHoldVisuals(ep, hold); // idempotent, re-asserts the hint every frame
                return true; // held: keep the extraction frozen
            }

            if (newState == ExtractionPoint.State.Success || newState == ExtractionPoint.State.Surplus)
            {
                if (!IsShop(ep))
                {
                    // The button is built here as well as in the Start prefix. Reaching Success
                    // means this extraction point is fully alive, so building the button at this
                    // point removes any dependency on having caught Start at the right moment -
                    // which is exactly what went wrong when the level was still loading.
                    EnsureButton(ep);
                    ApplyHoldVisuals(ep, hold); // target reached: announce the hold
                }

                return false;
            }

            // Any other transition (Cancel, Extracting, Complete, Idle, ...) ends the hold.
            if (hold.Confirmed)
                hold.Confirmed = false;

            RestoreTubeText(ep, hold);
            HideButton(hold);
            return false;
        }

        /// <summary>
        /// Prefix helper for ExtractionPoint.OnClick: returns true when the vanilla press should
        /// be consumed as a confirmation.
        /// </summary>
        public static bool HandleButtonPress(ExtractionPoint ep)
        {
            if (ep == null || _currentState == null || Settings == null || !Settings.Enabled.Value)
                return false;

            if (!IsHolding(ep))
                return false; // not holding: let the vanilla button logic run untouched

            ConfirmExtraction(ep);
            return true; // consume the press; vanilla would early-return here anyway
        }

        /// <summary>Applies a confirmation from the confirm button (or the original button).</summary>
        public static void ConfirmExtraction(ExtractionPoint ep)
        {
            if (ep == null || _currentState == null)
                return;

            HoldState hold = Get(ep);

            if (SemiFunc.IsMultiplayer() && SemiFunc.IsNotMasterClient())
            {
                // State changes are host-authoritative, so ask the host to start the countdown.
                if (RaiseConfirmRequest(ep))
                    Log?.LogInfo("Confirmation press - requested the countdown from the host");
                else
                    hold.Confirmed = true; // best effort fallback
            }
            else
            {
                hold.Confirmed = true;
                Log?.LogInfo("Extraction confirmed - countdown starting");
            }
        }

        /// <summary>True while this point sits in Success/Surplus with the countdown held.</summary>
        public static bool IsHolding(ExtractionPoint ep)
        {
            if (ep == null || IsShop(ep))
                return false;

            ExtractionPoint.State state = (ExtractionPoint.State)_currentState.GetValue(ep);
            return state == ExtractionPoint.State.Success || state == ExtractionPoint.State.Surplus;
        }

        /// <summary>
        /// True while the point is in a state where the confirm button is of any use: everything
        /// except idle, extracting, complete and tax-return. A button that only appears during the
        /// final hold reads as "the assets never loaded", because the hold is over in a couple of
        /// seconds.
        /// </summary>
        public static bool ShouldShowButton(ExtractionPoint ep)
        {
            if (ep == null || _currentState == null || IsShop(ep))
                return false;

            ExtractionPoint.State state = (ExtractionPoint.State)_currentState.GetValue(ep);
            switch (state)
            {
                case ExtractionPoint.State.Idle:       // not in use yet
                case ExtractionPoint.State.Extracting: // haul is already on its way
                case ExtractionPoint.State.Complete:
                case ExtractionPoint.State.TaxReturn:
                    return false;
                default:
                    return true;
            }
        }

        /// <summary>True while the local player is holding down the given grabbable button.</summary>
        public static bool IsLocallyGrabbed(StaticGrabObject grabObject)
        {
            try
            {
                PhysGrabber grabber = PhysGrabber.instance;
                if (grabber == null || grabObject == null)
                    return false;

                return ReferenceEquals(_grabbedStaticGrabObject.GetValue(grabber), grabObject);
            }
            catch
            {
                return false;
            }
        }

        private static bool IsShop(ExtractionPoint ep) => (bool)_isShop.GetValue(ep);

        // ------------------------------------------------------------------ the button

        /// <summary>
        /// Runs BEFORE vanilla ExtractionPoint.Start, because that method destroys the whole
        /// shopStation hierarchy in any level that is not a shop. Cloning afterwards would find
        /// nothing.
        ///
        /// isShop is assigned inside Start, so it is still null here - the level name is checked
        /// directly instead. The real shop is left completely untouched: its button keeps buying.
        /// </summary>
        public static void PrepareShopButton(ExtractionPoint ep)
        {
            try
            {
                if (ep == null)
                    return;

                if (!_loggedFirstInvocation)
                {
                    _loggedFirstInvocation = true;
                    Log?.LogInfo("ExtractionPoint.Start reached - preparing the confirm button.");
                }

                if (Settings == null)
                {
                    ReportReason("settings not ready yet");
                    return;
                }

                if (!Settings.Enabled.Value)
                    return; // the player turned the mod off; nothing to report

                if (!Settings.SpawnButton.Value)
                {
                    ReportReason("Button/Enabled is false in the config");
                    return;
                }

                if (SemiFunc.RunIsShop())
                    return; // the real shop keeps its own working purchase button

                if (Get(ep).Button != null)
                    return; // already built for this extraction point

                EnsureButton(ep);
            }
            catch (Exception ex)
            {
                ReportPatchError("PrepareShopButton", ex);
            }
        }

        /// <summary>
        /// Builds the confirm button for this extraction point if it does not have one yet.
        ///
        /// Called from two places on purpose. The Start prefix is the normal, early path; the
        /// Success/Surplus transition is the safety net, because by then the extraction point is
        /// guaranteed to exist and be fully initialised. Between them the button gets built whether
        /// or not the level finished loading before the player got there.
        ///
        /// Safe to call repeatedly - it does nothing once the button exists.
        /// </summary>
        private static void EnsureButton(ExtractionPoint ep)
        {
            if (ep == null || Settings == null || !Settings.Enabled.Value || !Settings.SpawnButton.Value)
                return;

            if (Get(ep).Button != null)
                return;

            try
            {
                if (SemiFunc.RunIsShop())
                    return; // the real shop keeps its own working purchase button

                GameObject template = EnsureStandTemplate(ep);
                if (template == null)
                {
                    ReportReason(
                        "no shop stand found on this extraction point and none cached yet - " +
                        "if this is the first extraction point of the run, check that it has a " +
                        "'Shop Station' child");
                    return;
                }

                // worldPositionStays=false: the clone keeps the exact local transform the game
                // authored, which is what makes it line up with the shop on every level whatever
                // the machine's rotation.
                GameObject clone = UnityEngine.Object.Instantiate(template, ep.transform, false);
                clone.name = "ExtractionConfirmButton";
                clone.SetActive(true);

                StaticGrabObject grab = clone.GetComponentInChildren<StaticGrabObject>(true);
                if (grab == null)
                {
                    Log?.LogWarning("Cloned shop stand has no StaticGrabObject - no confirm button.");
                    UnityEngine.Object.Destroy(clone);
                    return;
                }

                grab.enabled = true;
                grab.hoverText = Settings.ButtonHint.Value;

                ConfirmButton button = clone.AddComponent<ConfirmButton>();
                button.Setup(ep, grab, () => ConfirmExtraction(ep));
                button.SetVisible(false);

                Get(ep).Button = button;
                Log?.LogInfo($"Confirm button created from the shop stand at {clone.transform.position}");
            }
            catch (Exception ex)
            {
                ReportPatchError("PrepareShopButton", ex);
            }
        }

        /// <summary>
        /// Returns the shared shop stand, creating it from the first extraction point that has
        /// one. Never null once any extraction point with a shop station has been seen.
        /// </summary>
        private static GameObject EnsureStandTemplate(ExtractionPoint ep)
        {
            if (_standTemplate != null)
                return _standTemplate;

            Transform shopButton = _shopButton?.GetValue(ep) as Transform;
            if (shopButton == null)
            {
                Transform shopStation = _shopStation?.GetValue(ep) as Transform;
                shopButton = shopStation != null ? shopStation.Find("Shop Button") : null;
            }

            if (shopButton == null)
                return null;

            var clone = UnityEngine.Object.Instantiate(shopButton.gameObject);
            clone.name = "ExtractionConfirmButtonTemplate";
            clone.transform.localPosition = ShopButtonFallbackLocalPosition;
            clone.SetActive(false);

            if (!DisableShopBehaviour(clone))
            {
                Log?.LogError(
                    "The shop stand has no StaticGrabObject - the confirm button cannot work at all.");
                UnityEngine.Object.Destroy(clone);
                return null;
            }

            // Survives scene changes, because the template is reused by later levels.
            UnityEngine.Object.DontDestroyOnLoad(clone);

            _standTemplate = clone;
            ReportedReasons.Remove("no shop stand found on this extraction point and none cached yet - if this is the first extraction point of the run, check that it has a 'Shop Station' child");
            Log?.LogInfo("Cached the shop stand as the confirm button template.");
            return _standTemplate;
        }

        /// <summary>
        /// Turns the shop stand into a neutral button.
        ///
        /// The clone carries whatever components the shop button had, including the ones that run
        /// the purchase. Those are disabled so that pressing this copy cannot try to buy anything -
        /// the mod's own handler confirms the extraction instead. Only the grab components are
        /// left on: StaticGrabObject is what makes the button physically pressable.
        ///
        /// Matched by name rather than by type because a missing assembly turns a type check into
        /// a null reference at the worst possible moment.
        /// </summary>
        private static bool DisableShopBehaviour(GameObject root)
        {
            foreach (MonoBehaviour behaviour in root.GetComponentsInChildren<MonoBehaviour>(true))
            {
                if (behaviour == null)
                    continue;

                string typeName = behaviour.GetType().Name;

                bool isGrabComponent =
                    typeName == nameof(StaticGrabObject)
                    || typeName.IndexOf("GrabArea", StringComparison.OrdinalIgnoreCase) >= 0
                    || typeName == nameof(PhysGrabObjectGrabArea);

                if (isGrabComponent)
                    continue;

                behaviour.enabled = false;
            }

            return root.GetComponentInChildren<StaticGrabObject>(true) != null;
        }

        /// <summary>Logs a reason for not building a button, once per distinct reason.</summary>
        private static void ReportReason(string reason)
        {
            if (ReportedReasons.Add(reason))
                Log?.LogWarning("No confirm button: " + reason);
        }

        /// <summary>Called every frame for each extraction point; shows the button while it is in use.</summary>
        public static void Tick(ExtractionPoint ep)
        {
            if (ep == null || Settings == null || !Settings.Enabled.Value)
                return;

            HoldState hold;
            if (!Holds.TryGetValue(ep, out hold) || hold.Button == null)
                return;

            bool shouldShow = ShouldShowButton(ep) && Settings.SpawnButton.Value;
            if (hold.Button.gameObject.activeSelf == shouldShow)
                return;

            hold.Button.SetVisible(shouldShow);
            Log?.LogInfo(shouldShow
                ? "Confirm button shown"
                : "Confirm button hidden");
        }

        private static void HideButton(HoldState hold)
        {
            if (hold != null && hold.Button != null && hold.Button.gameObject.activeSelf)
                hold.Button.SetVisible(false);
        }

        // ------------------------------------------------------------------ tube text

        private static void ApplyHoldVisuals(ExtractionPoint ep, HoldState hold)
        {
            if (hold.TextApplied)
                return;

            try
            {
                hold.TubeTextOriginal = _tubeTextString.GetValue(ep) as string;
                hold.TubeColorOriginal = (Color)_tubeTextColor.GetValue(ep);
                hold.TextApplied = true;

                SetTubeText(ep, Settings.HoldText.Value, HoldColor);
                Log?.LogInfo($"Extraction held - press the confirm button to start the countdown");

                // A hold can only happen inside a live networked level, and the event hook is
                // installed here rather than at startup.
                if (SemiFunc.IsMultiplayer())
                    ExtractionConfirmPlugin.Instance?.EnsureNetworkHook();
            }
            catch (Exception ex)
            {
                hold.TextApplied = false;
                ReportPatchError("ApplyHoldVisuals", ex);
            }
        }

        private static void RestoreTubeText(ExtractionPoint ep, HoldState hold)
        {
            if (hold == null || !hold.TextApplied)
                return;

            hold.TextApplied = false;

            try
            {
                if (hold.TubeTextOriginal != null)
                    SetTubeText(ep, hold.TubeTextOriginal, hold.TubeColorOriginal);
            }
            catch (Exception ex)
            {
                ReportPatchError("RestoreTubeText", ex);
            }
        }

        private static void SetTubeText(ExtractionPoint ep, string text, Color color)
        {
            _tubeScreenTextChange.Invoke(ep, new object[] { text ?? string.Empty, color });
        }

        // ------------------------------------------------------------------ plumbing

        private static HoldState Get(ExtractionPoint ep)
        {
            if (Holds.Count > 16)
                PruneDestroyed();

            HoldState hold;
            if (!Holds.TryGetValue(ep, out hold))
            {
                hold = new HoldState();
                Holds.Add(ep, hold);
            }

            return hold;
        }

        private static void PruneDestroyed()
        {
            List<ExtractionPoint> dead = null;

            foreach (KeyValuePair<ExtractionPoint, HoldState> pair in Holds)
            {
                if (pair.Key == null)
                {
                    if (dead == null)
                        dead = new List<ExtractionPoint>();
                    dead.Add(pair.Key);
                }
            }

            if (dead == null)
                return;

            foreach (ExtractionPoint key in dead)
                Holds.Remove(key);
        }

        // ------------------------------------------------------------------ multiplayer

        /// <summary>Asks the host (who owns the state machine) to accept the confirmation.</summary>
        private static bool RaiseConfirmRequest(ExtractionPoint ep)
        {
            PhotonView view = ep.GetComponent<PhotonView>();
            if (view == null)
            {
                Log?.LogWarning("Extraction point has no PhotonView; cannot reach the host");
                return false;
            }

            PhotonNetwork.RaiseEvent(
                ConfirmEventCode,
                new object[] { view.ViewID },
                new RaiseEventOptions(),
                SendOptions.SendReliable);

            return true;
        }

        /// <summary>Host side: apply a confirmation raised by another player.</summary>
        public static void OnPhotonEvent(EventData eventData)
        {
            try
            {
                if (eventData == null || eventData.Code != ConfirmEventCode)
                    return;

                if (!PhotonNetwork.IsMasterClient)
                    return;

                object[] payload = eventData.CustomData as object[];
                if (payload == null || payload.Length < 1)
                    return;

                int viewId = Convert.ToInt32(payload[0]);
                PhotonView view = PhotonView.Find(viewId);
                if (view == null)
                    return;

                ExtractionPoint ep = view.GetComponent<ExtractionPoint>();
                if (ep == null || !IsHolding(ep))
                    return;

                Get(ep).Confirmed = true;
                Log?.LogInfo("Confirmation received from a player - countdown starting");
            }
            catch (Exception ex)
            {
                ReportPatchError("OnPhotonEvent", ex);
            }
        }

        /// <summary>Logs each distinct patch failure once, so a hot-reload glitch cannot spam the log.</summary>
        public static void ReportPatchError(string where, Exception ex)
        {
            if (ReportedErrors.Add(where))
                Log?.LogError($"Patch error in {where}: {ex}");
        }
    }
}